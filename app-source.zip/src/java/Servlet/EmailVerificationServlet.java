package Servlet;

import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

@WebServlet(name = "EmailVerificationServlet", urlPatterns = {"/EmailVerificationServlet"})
public class EmailVerificationServlet extends HttpServlet {
    private static final SecureRandom RANDOM = new SecureRandom();

    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        response.setContentType("application/json;charset=UTF-8");

        String correo = request.getParameter("correo");
        if (correo == null || !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
            response.getWriter().write("{\"ok\":false,\"message\":\"Escribe un correo valido.\"}");
            return;
        }

        String codigo = String.format("%06d", RANDOM.nextInt(1000000));
        HttpSession session = request.getSession();
        session.setAttribute("registroCorreo", correo.trim().toLowerCase());
        session.setAttribute("registroCodigo", codigo);
        session.setAttribute("registroCodigoExpira", System.currentTimeMillis() + (10 * 60 * 1000));

        String apiKey = System.getenv("BREVO_API_KEY");
        String remitente = System.getenv("MAIL_FROM");
        if (apiKey == null || apiKey.trim().isEmpty() || remitente == null || remitente.trim().isEmpty()) {
            response.getWriter().write("{\"ok\":false,\"message\":\"El correo de verificación aún no está configurado.\",\"setupRequired\":true}");
            return;
        }

        try {
            enviarConBrevo(apiKey.trim(), remitente.trim(), correo.trim(), codigo);
            response.getWriter().write("{\"ok\":true,\"message\":\"Enviamos un código de 6 dígitos a tu correo. Vence en 10 minutos.\"}");
        } catch (IOException ex) {
            response.getWriter().write("{\"ok\":false,\"message\":\"No fue posible enviar el correo. Intenta nuevamente más tarde.\"}");
            getServletContext().log("Error enviando código por Brevo", ex);
        }
    }

    private void enviarConBrevo(String apiKey, String remitente, String destinatario, String codigo) throws IOException {
        URL url = new URL("https://api.brevo.com/v3/smtp/email");
        HttpURLConnection con = (HttpURLConnection) url.openConnection();
        con.setRequestMethod("POST");
        con.setConnectTimeout(10000);
        con.setReadTimeout(10000);
        con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        con.setRequestProperty("Accept", "application/json");
        con.setRequestProperty("api-key", apiKey);

        String asunto = "Código de verificación - Una Pa' La Sed";
        String html = "<div style='font-family:Arial,sans-serif;color:#211805'><h2>Una Pa' La Sed</h2>"
                + "<p>Tu código de verificación es:</p><p style='font-size:28px;font-weight:bold;letter-spacing:5px'>"
                + codigo + "</p><p>Este código vence en 10 minutos. No lo compartas con nadie.</p></div>";
        String json = "{\"sender\":{\"email\":\"" + escapar(remitente) + "\",\"name\":\"Una Pa' La Sed\"},"
                + "\"to\":[{\"email\":\"" + escapar(destinatario) + "\"}],"
                + "\"subject\":\"" + escapar(asunto) + "\",\"htmlContent\":\"" + escapar(html) + "\"}";

        try (OutputStream salida = con.getOutputStream()) {
            salida.write(json.getBytes(StandardCharsets.UTF_8));
        }
        int estado = con.getResponseCode();
        if (estado < 200 || estado >= 300) {
            throw new IOException("Brevo respondió HTTP " + estado);
        }
    }

    private String escapar(String valor) {
        return valor.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "");
    }
}
