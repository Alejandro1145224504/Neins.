package Servlet;

import Controlador.UsuariosDAO;
import Modelo.Usuarios;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;
import java.io.IOException;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.security.SecureRandom;

@WebServlet(name = "RecuperarClaveServlet", urlPatterns = {"/RecuperarClaveServlet"})
public class RecuperarClaveServlet extends HttpServlet {
    private static final SecureRandom RANDOM = new SecureRandom();
    @Override protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8"); String accion = request.getParameter("accion");
        String base = request.getContextPath() + "/Vista/RecuperarClave.jsp"; HttpSession session = request.getSession();
        if ("enviar".equals(accion)) {
            String correo = request.getParameter("correo");
            if (correo == null || !correo.trim().matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) { response.sendRedirect(base + "?error=correo"); return; }
            Usuarios usuario = new UsuariosDAO().buscarPorCorreo(correo.trim());
            if (usuario == null) { response.sendRedirect(base + "?error=noexiste"); return; }
            String apiKey = System.getenv("BREVO_API_KEY"), remitente = System.getenv("MAIL_FROM");
            if (vacio(apiKey) || vacio(remitente)) { response.sendRedirect(base + "?error=config"); return; }
            String codigo = String.format("%06d", RANDOM.nextInt(1_000_000));
            try {
                enviarConBrevo(apiKey.trim(), remitente.trim(), usuario.getCorreo(), codigo);
                session.setAttribute("recuperacion_id_usuario", usuario.getId_usuarios()); session.setAttribute("recuperacion_correo", usuario.getCorreo());
                session.setAttribute("recuperacion_codigo", codigo); session.setAttribute("recuperacion_expira", System.currentTimeMillis() + 600000L);
                session.setAttribute("recuperacion_clave_en_curso", Boolean.TRUE); session.removeAttribute("recuperacion_autorizada");
                response.sendRedirect(base + "?paso=codigo");
            } catch (IOException ex) { getServletContext().log("No se pudo enviar código de recuperación", ex); response.sendRedirect(base + "?error=envio"); }
            return;
        }
        if ("verificar".equals(accion)) {
            String codigo = request.getParameter("codigo"), guardado = (String) session.getAttribute("recuperacion_codigo");
            Long expira = (Long) session.getAttribute("recuperacion_expira"); Integer id = (Integer) session.getAttribute("recuperacion_id_usuario");
            if (id == null || guardado == null || expira == null || System.currentTimeMillis() > expira) { response.sendRedirect(base + "?error=expirado"); return; }
            if (!guardado.equals(codigo != null ? codigo.trim() : "")) { response.sendRedirect(base + "?paso=codigo&error=codigo"); return; }
            session.setAttribute("clave_vencida_id_usuario", id); session.setAttribute("clave_vencida_correo", session.getAttribute("recuperacion_correo"));
            session.setAttribute("recuperacion_autorizada", Boolean.TRUE); session.removeAttribute("recuperacion_codigo");
            response.sendRedirect(request.getContextPath() + "/Vista/CambiarClave.jsp?recuperar=1"); return;
        }
        response.sendRedirect(base);
    }
    private boolean vacio(String valor) { return valor == null || valor.trim().isEmpty(); }
    private void enviarConBrevo(String apiKey, String remitente, String destino, String codigo) throws IOException {
        HttpURLConnection con = (HttpURLConnection) new URL("https://api.brevo.com/v3/smtp/email").openConnection();
        con.setRequestMethod("POST"); con.setConnectTimeout(10000); con.setReadTimeout(10000); con.setDoOutput(true);
        con.setRequestProperty("Content-Type", "application/json; charset=UTF-8"); con.setRequestProperty("Accept", "application/json"); con.setRequestProperty("api-key", apiKey);
        String html = "<div style='font-family:Arial,sans-serif;color:#1b1508;max-width:540px;margin:auto'><h2 style='color:#b78310'>Una Pa' La Sed</h2><p>Solicitaste recuperar tu contraseña.</p><p>Usa este código de verificación:</p><p style='font-size:30px;font-weight:bold;letter-spacing:6px'>" + codigo + "</p><p>Vence en 10 minutos. Si no fuiste tú, ignora este correo.</p></div>";
        String json = "{\"sender\":{\"email\":\"" + esc(remitente) + "\",\"name\":\"Una Pa' La Sed\"},\"to\":[{\"email\":\"" + esc(destino) + "\"}],\"subject\":\"Recuperación de contraseña - Una Pa' La Sed\",\"htmlContent\":\"" + esc(html) + "\"}";
        try (OutputStream out = con.getOutputStream()) { out.write(json.getBytes(StandardCharsets.UTF_8)); }
        int estado = con.getResponseCode(); if (estado < 200 || estado >= 300) throw new IOException("Brevo respondió HTTP " + estado);
    }
    private String esc(String s) { return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", ""); }
}
