package Servlet.Api;

import Controlador.Conexion;
import Controlador.JsonUtil;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 * Puente usado por la app Flutter. Registra una solicitud; nunca descuenta la
 * deuda hasta que un administrador la confirme desde el panel web.
 */
@WebServlet(name = "PagoApiServlet", urlPatterns = {"/api/pagos"})
public class PagoApiServlet extends HttpServlet {
    private final Conexion conexion = new Conexion();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");
        try {
            int idUsuario = Integer.parseInt(req.getParameter("id_usuario"));
            int idFiado = Integer.parseInt(req.getParameter("id_fiado"));
            double monto = Double.parseDouble(req.getParameter("monto"));
            String metodo = req.getParameter("metodo");
            if (monto <= 0 || metodo == null || metodo.trim().isEmpty()) throw new IllegalArgumentException();

            try (Connection con = conexion.getConnection()) {
                crearTablaSiNoExiste(con);
                int idCliente = obtenerClientePropietario(con, idUsuario, idFiado);
                if (idCliente == 0) throw new SecurityException("El fiado no pertenece al usuario autenticado");
                double saldo = saldoPendiente(con, idFiado);
                if (saldo <= 0) throw new IllegalStateException("Este fiado no tiene saldo pendiente");
                if (monto > saldo) monto = saldo;
                int idMedio = medioPago(con, metodo);
                if (idMedio == 0) throw new IllegalArgumentException("Metodo de pago no disponible");
                String referencia = "MOB-" + Long.toString(System.currentTimeMillis(), 36).toUpperCase();
                try (PreparedStatement ps = con.prepareStatement(
                        "INSERT INTO Solicitudes_Transferencia (monto, referencia, estado, observaciones, id_fiado, id_cliente, id_medio_pago) VALUES (?, ?, 'Pendiente', ?, ?, ?, ?)")) {
                    ps.setDouble(1, monto); ps.setString(2, referencia);
                    ps.setString(3, "Solicitud creada desde Flutter - " + metodo);
                    ps.setInt(4, idFiado); ps.setInt(5, idCliente); ps.setInt(6, idMedio);
                    ps.executeUpdate();
                }
                resp.getWriter().write("{\"ok\":true,\"referencia\":\"" + JsonUtil.esc(referencia) + "\",\"monto\":" + monto + "}");
            }
        } catch (SecurityException e) {
            resp.setStatus(HttpServletResponse.SC_FORBIDDEN);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"" + JsonUtil.esc(e.getMessage()) + "\"}");
        } catch (Exception e) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"No fue posible crear la solicitud de pago\"}");
        }
    }

    private void crearTablaSiNoExiste(Connection con) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("CREATE TABLE IF NOT EXISTS Solicitudes_Transferencia (id_solicitud INT AUTO_INCREMENT PRIMARY KEY, fecha_solicitud DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP, monto DECIMAL(10,2) NOT NULL, referencia VARCHAR(80) NOT NULL UNIQUE, estado VARCHAR(20) NOT NULL DEFAULT 'Pendiente', observaciones VARCHAR(255), id_fiado INT NOT NULL, id_cliente INT NOT NULL, id_medio_pago INT NOT NULL)")) { ps.executeUpdate(); }
    }
    private int obtenerClientePropietario(Connection con, int usuario, int fiado) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("SELECT f.id_cliente FROM Fiado f JOIN clientes c ON c.id_cliente=f.id_cliente WHERE f.id_fiado=? AND c.id_usuario=?")) {
            ps.setInt(1, fiado); ps.setInt(2, usuario); ResultSet rs=ps.executeQuery(); return rs.next()?rs.getInt(1):0;
        }
    }
    private double saldoPendiente(Connection con, int fiado) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("SELECT saldo_pendiente FROM Fiado WHERE id_fiado=?")) { ps.setInt(1,fiado); ResultSet rs=ps.executeQuery(); return rs.next()?rs.getDouble(1):0; }
    }
    private int medioPago(Connection con, String metodo) throws Exception {
        try (PreparedStatement ps = con.prepareStatement("SELECT id_medio_pago FROM medio_pago WHERE LOWER(descripcion_medio_pago)=LOWER(?) LIMIT 1")) { ps.setString(1,metodo); ResultSet rs=ps.executeQuery(); return rs.next()?rs.getInt(1):0; }
    }
}
