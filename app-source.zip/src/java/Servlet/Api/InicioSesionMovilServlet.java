package Servlet.Api;

import Controlador.JsonUtil;
import Controlador.UsuariosDAO;
import Modelo.Usuarios;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.security.MessageDigest;

/** Punto de acceso exclusivo para la aplicación Flutter. */
@WebServlet(name = "InicioSesionMovilServlet", urlPatterns = {"/api/movil/iniciar-sesion"})
public class InicioSesionMovilServlet extends HttpServlet {
    private final UsuariosDAO dao = new UsuariosDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");
        String correo = req.getParameter("correo");
        String clave = req.getParameter("clave");
        if (correo == null || clave == null || correo.trim().isEmpty() || clave.trim().isEmpty()) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"Correo y clave son obligatorios\"}");
            return;
        }
        Usuarios u = dao.buscarPorCorreo(correo.trim());
        if (u == null || !sha256(clave).equals(u.getClave())) {
            resp.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"Correo o clave incorrectos\"}");
            return;
        }
        resp.getWriter().write("{\"ok\":true,\"id_usuarios\":" + u.getId_usuarios()
                + ",\"nombre\":\"" + JsonUtil.esc(u.getNombre()) + "\",\"rol\":\""
                + JsonUtil.esc(u.getRol()) + "\"}");
    }

    private String sha256(String texto) {
        try {
            byte[] hash = MessageDigest.getInstance("SHA-256").digest(texto.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : hash) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Exception e) { return ""; }
    }
}
