package Servlet.Api;

import Controlador.JsonUtil;
import Controlador.UsuariosDAO;
import Modelo.Usuarios;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import java.io.IOException;

/** Registro de clientes desde Flutter. Los administradores solo se crean desde el portal web. */
@WebServlet(name = "RegistroMovilServlet", urlPatterns = {"/api/movil/registro"})
public class RegistroMovilServlet extends HttpServlet {
    private final UsuariosDAO dao = new UsuariosDAO();

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws IOException {
        req.setCharacterEncoding("UTF-8");
        resp.setContentType("application/json; charset=UTF-8");
        String nombre = value(req, "nombre");
        String apellidos = value(req, "apellidos");
        String identificacion = value(req, "identificacion");
        String telefono = value(req, "telefono");
        String correo = value(req, "correo").toLowerCase();
        String clave = req.getParameter("clave");
        if (nombre.isEmpty() || apellidos.isEmpty() || identificacion.isEmpty()
                || telefono.isEmpty() || correo.isEmpty() || clave == null || clave.length() < 8) {
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"Completa los datos. La clave debe tener al menos 8 caracteres\"}");
            return;
        }
        String duplicado = dao.validarDuplicado(correo, telefono, identificacion);
        if (duplicado != null) {
            resp.setStatus(HttpServletResponse.SC_CONFLICT);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"El " + JsonUtil.esc(duplicado) + " ya está registrado\"}");
            return;
        }
        Usuarios u = new Usuarios();
        u.setNombre(nombre); u.setApellido(apellidos); u.setIdentificacion(identificacion);
        u.setTelefono(telefono); u.setCorreo(correo); u.setClave(clave);
        u.setRol("cliente"); u.setIdRol(2); u.setIdTipoDocumento(1);
        u.setAceptoTerminos(true); u.setIpAceptoTerminos(req.getRemoteAddr());
        u.setVersionTerminos("1.0");
        if (!dao.insertar(u)) {
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            resp.getWriter().write("{\"ok\":false,\"mensaje\":\"No fue posible crear la cuenta\"}");
            return;
        }
        resp.setStatus(HttpServletResponse.SC_CREATED);
        resp.getWriter().write("{\"ok\":true,\"mensaje\":\"Cuenta creada. Ya puedes iniciar sesión\"}");
    }

    private String value(HttpServletRequest req, String name) {
        String value = req.getParameter(name);
        return value == null ? "" : value.trim();
    }
}
