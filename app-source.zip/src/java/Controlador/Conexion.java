package Controlador;

import java.sql.Connection;
import java.sql.DriverManager;

public class Conexion {

    Connection con;
    private static final String DEFAULT_URL =
            "jdbc:mysql://localhost:3307/Neins?useSSL=false&serverTimezone=America/Bogota&allowPublicKeyRetrieval=true";
    private static final String DEFAULT_USER = "root";
    private static final String DEFAULT_PASSWORD = "";

    public Connection getConnection() {
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
            con = DriverManager.getConnection(
                    databaseUrl(),
                    config("NEINS_DB_USER", config("MYSQLUSER", DEFAULT_USER)),
                    config("NEINS_DB_PASSWORD", config("MYSQLPASSWORD", DEFAULT_PASSWORD))
            );
        } catch (Exception e) {
            System.err.println("[NEINS] Error de conexión a MySQL: " + e.getMessage());
            throw new RuntimeException("No se pudo conectar a la base de datos: " + e.getMessage(), e);
        }
        return con;
    }

    private String config(String key, String defaultValue) {
        String value = System.getenv(key);
        if (value == null || value.trim().isEmpty()) {
            value = System.getProperty(key);
        }
        return value == null || value.trim().isEmpty() ? defaultValue : value.trim();
    }

    /**
     * Prioriza la configuración propia y, en Railway, usa las variables
     * expuestas por el servicio MySQL del mismo proyecto.
     */
    private String databaseUrl() {
        String ownUrl = config("NEINS_DB_URL", "");
        if (!ownUrl.isEmpty()) return ownUrl;

        String host = config("MYSQLHOST", "");
        String database = config("MYSQLDATABASE", "");
        if (!host.isEmpty() && !database.isEmpty()) {
            String port = config("MYSQLPORT", "3306");
            return "jdbc:mysql://" + host + ":" + port + "/" + database
                    + "?useSSL=true&serverTimezone=America/Bogota&allowPublicKeyRetrieval=true";
        }
        return DEFAULT_URL;
    }
}
