package Controlador;

import Modelo.Productos;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class ProductosDAO {
    Conexion conexion = new Conexion();

    public boolean insertar(Productos p) {
        try (Connection con = conexion.getConnection()) {
            String sql = "INSERT INTO Productos (nombre, precio, stock) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setFloat(2, p.getPrecio());
            ps.setInt(3, p.getStock());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error insertar producto: " + e);
            return false;
        }
    }

    public List<Productos> listar() {
        List<Productos> lista = new ArrayList<>();
        String sql = "SELECT id_productos, nombre, precio, stock FROM Productos "
                   + "WHERE COALESCE(estado, 1) = 1 ORDER BY nombre";
        try (Connection con = conexion.getConnection();
             PreparedStatement ps = con.prepareStatement(sql);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                Productos p = new Productos();
                p.setId_productos(rs.getInt("id_productos"));
                p.setNombre(rs.getString("nombre"));
                p.setPrecio(rs.getFloat("precio"));
                p.setStock(rs.getInt("stock"));
                lista.add(p);
            }
        } catch (Exception e) {
            System.out.println("Error listar productos: " + e);
        }
        return lista;
    }

    public boolean actualizar(Productos p) {
        try (Connection con = conexion.getConnection()) {
            String sql = "UPDATE Productos SET nombre=?, precio=?, stock=? WHERE id_productos=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setString(1, p.getNombre());
            ps.setFloat(2, p.getPrecio());
            ps.setInt(3, p.getStock());
            ps.setInt(4, p.getId_productos());
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error actualizar producto: " + e);
            return false;
        }
    }

    public boolean eliminar(int id) {
        try (Connection con = conexion.getConnection()) {
            // Conserva ventas y fiados históricos; solo lo retira del catálogo.
            String sql = "UPDATE Productos SET estado=0 WHERE id_productos=?";
            PreparedStatement ps = con.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            return true;
        } catch (Exception e) {
            System.out.println("Error eliminar producto: " + e);
            return false;
        }
    }
}
