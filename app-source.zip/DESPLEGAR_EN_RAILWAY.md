# Desplegar Una Pa' La Sed en Railway

## 1. Crear el proyecto

1. Crea un repositorio nuevo en GitHub.
2. Descomprime `Neins_mejorado_v10.zip` y sube el contenido de la carpeta `source` al repositorio. Deben quedar `Dockerfile`, `railway.toml` y `build/` en la raíz del repositorio.
3. En Railway selecciona **New Project** -> **Deploy from GitHub Repo** y elige ese repositorio.

## 2. Agregar MySQL

1. En el mismo proyecto Railway, pulsa **New** -> **Database** -> **MySQL**.
2. Espera a que el servicio quede activo.
3. En el servicio web, abre **Variables** y agrega estas referencias:

```text
MYSQLHOST=${{MySQL.MYSQLHOST}}
MYSQLPORT=${{MySQL.MYSQLPORT}}
MYSQLDATABASE=${{MySQL.MYSQLDATABASE}}
MYSQLUSER=${{MySQL.MYSQLUSER}}
MYSQLPASSWORD=${{MySQL.MYSQLPASSWORD}}
```

Si el servicio se llama distinto de `MySQL`, Railway mostrará el nombre correcto al elegir cada referencia desde el autocompletado.

## 3. Crear las tablas

1. En el servicio MySQL, entra a **Connect** y habilita **Public Access** temporalmente.
2. Copia `MYSQL_PUBLIC_URL`.
3. Desde MySQL Workbench, importa `database/Neins_SQL_FINAL.sql` usando esa conexión, o ejecuta todo el archivo SQL.
4. Al terminar, puedes desactivar Public Access si no necesitas conectarte desde fuera de Railway.

## 4. Publicar

1. Vuelve al servicio web y abre **Settings** -> **Networking**.
2. Selecciona **Generate Domain**.
3. Espera a que finalice el deploy y abre el dominio generado.

El usuario inicial de la base limpia es `admin@neins.com` y la contraseña es `admin123`. Cámbiala tras el primer acceso.
