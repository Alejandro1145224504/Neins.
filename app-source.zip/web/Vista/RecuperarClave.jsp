<%@page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@page import="Controlador.UsuariosDAO, Modelo.Usuarios"%>

<%!
    private String h(String value) {
        if (value == null) return "";
        return value.replace("&", "&amp;")
                    .replace("<", "&lt;")
                    .replace(">", "&gt;")
                    .replace("\"", "&quot;")
                    .replace("'", "&#39;");
    }
%>

<%
    String error = null;

    if ("POST".equalsIgnoreCase(request.getMethod())) {
        String correo = request.getParameter("correo");
        UsuariosDAO dao = new UsuariosDAO();
        Usuarios usuario = dao.buscarPorCorreo(correo);
        if (usuario == null) {
            error = "No encontramos ninguna cuenta con ese correo.";
        } else {
            session.invalidate();
            session = request.getSession(true);
            session.setAttribute("clave_vencida_id_usuario", usuario.getId_usuarios());
            session.setAttribute("clave_vencida_correo", usuario.getCorreo());
            response.sendRedirect(request.getContextPath() + "/Vista/CambiarClave.jsp?recuperar=1");
            return;
        }
    }
%>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperar Contraseña — Una Pa' La Sed</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="../Estilos/global.css">
    <link rel="stylesheet" href="../Estilos/global.css">
</head>
<body>

<div class="form-container">

    <!-- Marca -->
    <div style="margin-bottom:28px;">
        <div style="width:56px;height:56px;margin:0 auto 14px;background:linear-gradient(135deg,rgba(212,175,55,.15),rgba(212,175,55,.05));border:1px solid rgba(212,175,55,.3);border-radius:16px;display:flex;align-items:center;justify-content:center;font-size:1.6rem;box-shadow:0 8px 24px rgba(212,175,55,.12);">
            🔑
        </div>
        <h1>Recuperar Contraseña</h1>
        <p class="subtitle">Cartera Digital</p>
    </div>

    <div class="divider"><span>Verificación</span></div>

    <!-- Error -->
    <% if (error != null) { %>
        <div class="alert alert-error">✕ &nbsp;<%= h(error) %></div>
    <% } %>

    <!-- Formulario -->
    <form method="post" id="recover-form">
        <div class="form-group">
            <label for="correo">Correo electrónico</label>
            <input type="email" name="correo" id="correo"
                   placeholder="usuario@correo.com"
                   required autocomplete="email">
        </div>

        <button type="submit" class="btn-primary" id="btn-submit">
            Continuar
        </button>
    </form>

    <!-- Volver -->
    <div class="back-link">
        <a href="../index.html">&larr; Volver al inicio</a>
    </div>

</div>

<script>
    document.getElementById('recover-form') && document.getElementById('recover-form').addEventListener('submit', function () {
        var btn = document.getElementById('btn-submit');
        if (btn) { btn.textContent = 'Buscando…'; btn.classList.add('loading'); }
    });
</script>

    <script src="../Scripts/premium-ui.js"></script>
</body>
</html>
