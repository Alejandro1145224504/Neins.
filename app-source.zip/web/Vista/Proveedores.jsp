<%@page contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@page import="Controlador.ProveedorDAO, Controlador.Conexion, Modelo.Proveedores, java.util.List, java.util.Map, java.util.HashMap"%>
<%@page import="java.sql.*"%>

<% boolean embedAdmin = "1".equals(request.getParameter("embed")); %>
<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proveedores — Neins</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cinzel:wght@500;700&family=Inter:wght@300;400;500;600&display=swap" rel="stylesheet">
    <style>
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }

        body {
            font-family: 'Inter', sans-serif;
            background: #0a0a0f;
            color: #e0d4b4;
            display: flex;
            min-height: 100vh;
        }

        /* ── SIDEBAR ── */
        .sidebar {
            width: 260px;
            min-height: 100vh;
            background: linear-gradient(180deg, #0d0d1a 0%, #0a0a0f 100%);
            border-right: 1px solid rgba(212,175,55,0.15);
            display: flex;
            flex-direction: column;
            padding: 0;
            position: fixed;
            top: 0; left: 0;
            z-index: 100;
        }

        .sidebar-brand {
            padding: 28px 24px 20px;
            border-bottom: 1px solid rgba(212,175,55,0.15);
        }
        .sidebar-brand h2 {
            font-family: 'Cinzel', serif;
            color: #d4af37;
            font-size: 1.4rem;
            letter-spacing: 2px;
        }
        .sidebar-brand p {
            color: rgba(212,175,55,0.5);
            font-size: 0.75rem;
            margin-top: 4px;
        }

        .sidebar-nav { padding: 20px 0; flex: 1; }

        .nav-section-title {
            padding: 8px 24px;
            font-size: 0.65rem;
            letter-spacing: 2px;
            color: rgba(212,175,55,0.4);
            text-transform: uppercase;
            margin-top: 8px;
        }

        .nav-item {
            display: flex;
            align-items: center;
            gap: 12px;
            padding: 11px 24px;
            color: rgba(224,212,180,0.7);
            text-decoration: none;
            font-size: 0.9rem;
            transition: all 0.25s;
            border-left: 3px solid transparent;
        }
        .nav-item:hover {
            background: rgba(212,175,55,0.08);
            color: #d4af37;
            border-left-color: rgba(212,175,55,0.4);
        }
        .nav-item.active {
            background: rgba(212,175,55,0.12);
            color: #d4af37;
            border-left-color: #d4af37;
            font-weight: 600;
        }
        .nav-item .icon { width: 18px; text-align: center; font-size: 1rem; }

        .sidebar-footer {
            padding: 20px 24px;
            border-top: 1px solid rgba(212,175,55,0.15);
        }
        .btn-logout {
            display: block;
            width: 100%;
            padding: 10px;
            background: transparent;
            border: 1px solid rgba(192,57,43,0.5);
            color: #e74c3c;
            border-radius: 8px;
            cursor: pointer;
            font-size: 0.85rem;
            text-align: center;
            text-decoration: none;
            transition: all 0.3s;
        }
        .btn-logout:hover { background: rgba(192,57,43,0.15); border-color: #e74c3c; }

        /* ── MAIN ── */
        .main-content {
            margin-left: 260px;
            flex: 1;
            padding: 40px;
            max-width: calc(100vw - 260px);
        }

        .page-header {
            margin-bottom: 32px;
            padding-bottom: 20px;
            border-bottom: 1px solid rgba(212,175,55,0.15);
        }
        .page-header h1 {
            font-family: 'Cinzel', serif;
            font-size: 1.8rem;
            color: #d4af37;
            letter-spacing: 1px;
        }
        .page-header p { color: rgba(224,212,180,0.5); margin-top: 6px; font-size: 0.9rem; }

        /* ── LAYOUT DOS COLUMNAS ── */
        .layout {
            display: grid;
            grid-template-columns: 380px 1fr;
            gap: 32px;
            align-items: start;
        }

        /* ── FORM CARD ── */
        .form-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 16px;
            padding: 28px;
        }
        .form-card h2 {
            font-family: 'Cinzel', serif;
            color: #d4af37;
            font-size: 1.1rem;
            margin-bottom: 22px;
            letter-spacing: 1px;
        }

        .edit-badge {
            display: inline-block;
            background: rgba(212,175,55,0.15);
            border: 1px solid rgba(212,175,55,0.4);
            color: #d4af37;
            padding: 6px 14px;
            border-radius: 20px;
            font-size: 0.8rem;
            margin-bottom: 18px;
        }

        .form-group { margin-bottom: 18px; }
        .form-group label {
            display: block;
            font-size: 0.82rem;
            color: rgba(212,175,55,0.8);
            margin-bottom: 7px;
            letter-spacing: 0.5px;
        }
        .form-group input {
            width: 100%;
            padding: 10px 14px;
            background: rgba(255,255,255,0.05);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 8px;
            color: #e0d4b4;
            font-size: 0.9rem;
            font-family: 'Inter', sans-serif;
            transition: border-color 0.3s;
            outline: none;
        }
        .form-group input:focus { border-color: #d4af37; background: rgba(212,175,55,0.05); }

        .btn-row { display: flex; gap: 10px; margin-top: 22px; }
        .btn-primary {
            flex: 1;
            padding: 11px;
            background: linear-gradient(135deg, #d4af37, #b8962e);
            color: #0a0a0f;
            border: none;
            border-radius: 8px;
            font-weight: 700;
            font-size: 0.9rem;
            cursor: pointer;
            transition: opacity 0.3s;
        }
        .btn-primary:hover { opacity: 0.85; }
        .btn-secondary {
            padding: 11px 18px;
            background: transparent;
            border: 1px solid rgba(212,175,55,0.3);
            color: rgba(212,175,55,0.7);
            border-radius: 8px;
            font-size: 0.9rem;
            cursor: pointer;
            text-decoration: none;
            display: flex;
            align-items: center;
            transition: all 0.3s;
        }
        .btn-secondary:hover { border-color: #d4af37; color: #d4af37; }

        /* ── TABLA ── */
        .table-card {
            background: rgba(255,255,255,0.03);
            border: 1px solid rgba(212,175,55,0.2);
            border-radius: 16px;
            overflow: hidden;
        }
        .table-card-header {
            padding: 18px 24px;
            border-bottom: 1px solid rgba(212,175,55,0.15);
            display: flex;
            align-items: center;
            justify-content: space-between;
        }
        .table-card-header h3 {
            font-family: 'Cinzel', serif;
            color: #d4af37;
            font-size: 1rem;
        }
        .count-badge {
            background: rgba(212,175,55,0.15);
            color: #d4af37;
            padding: 3px 12px;
            border-radius: 12px;
            font-size: 0.8rem;
        }

        table { width: 100%; border-collapse: collapse; }
        th {
            background: rgba(212,175,55,0.1);
            color: #d4af37;
            padding: 13px 16px;
            text-align: left;
            font-size: 0.8rem;
            letter-spacing: 1px;
            text-transform: uppercase;
        }
        td {
            padding: 13px 16px;
            border-bottom: 1px solid rgba(255,255,255,0.05);
            font-size: 0.9rem;
            color: rgba(224,212,180,0.85);
        }
        tr:last-child td { border-bottom: none; }
        tr:hover td { background: rgba(212,175,55,0.04); }

        .nit-badge {
            display: inline-block;
            background: rgba(52,152,219,0.15);
            border: 1px solid rgba(52,152,219,0.3);
            color: #5dade2;
            padding: 3px 10px;
            border-radius: 10px;
            font-size: 0.8rem;
            font-family: monospace;
        }

        .action-btns { display: flex; gap: 8px; }
        .btn-edit {
            background: transparent;
            border: 1px solid rgba(212,175,55,0.4);
            color: #d4af37;
            padding: 5px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.82rem;
            transition: all 0.3s;
            text-decoration: none;
        }
        .btn-edit:hover { background: rgba(212,175,55,0.15); }
        .btn-delete {
            background: transparent;
            border: 1px solid rgba(192,57,43,0.4);
            color: #e74c3c;
            padding: 5px 12px;
            border-radius: 6px;
            cursor: pointer;
            font-size: 0.82rem;
            transition: all 0.3s;
        }
        .btn-delete:hover { background: rgba(192,57,43,0.15); }

        .empty-state {
            text-align: center;
            padding: 50px 20px;
            color: rgba(224,212,180,0.35);
        }
        .empty-state .empty-icon { font-size: 2.5rem; margin-bottom: 12px; }

        /* ── ALERTAS ── */
        .alert {
            padding: 12px 18px;
            border-radius: 10px;
            margin-bottom: 22px;
            font-size: 0.9rem;
        }
        .alert-success {
            background: rgba(46,204,113,0.1);
            border: 1px solid rgba(46,204,113,0.3);
            color: #2ecc71;
        }
        .alert-error {
            background: rgba(192,57,43,0.1);
            border: 1px solid rgba(192,57,43,0.3);
            color: #e74c3c;
        }
    

        body.embed-admin {
            background: #0f0e0b !important;
            min-height: auto;
            display: block;
            overflow-x: hidden;
        }
        body.embed-admin .sidebar { display: none !important; }
        body.embed-admin .main-content {
            margin-left: 0 !important;
            max-width: none !important;
            width: 100% !important;
            padding: 28px 32px !important;
        }
        body.embed-admin .back-link,
        body.embed-admin .back-btn { display: none !important; }
        body.embed-admin .layout,
        body.embed-admin .content-grid { grid-template-columns: minmax(280px, 380px) minmax(420px, 1fr); }
        @media (max-width: 900px) {
            body.embed-admin .layout,
            body.embed-admin .content-grid { grid-template-columns: 1fr; }
        }

    </style>
    <link rel="stylesheet" href="../Estilos/global.css">
</head>
<body class='<%= embedAdmin ? "embed-admin" : "" %>'>

<%
    String usuario = (String) session.getAttribute("usuario");
    String rol     = (String) session.getAttribute("rol");
    if (usuario == null) { response.sendRedirect("Login.jsp"); return; }
    if (!"administrador".equals(rol)) { response.sendRedirect("MenuCliente.jsp"); return; }
%>

<!-- ══════════════════ SIDEBAR ══════════════════ -->
<% if (!embedAdmin) { %>
<aside class="sidebar">
    <div class="sidebar-brand">
        <h2>NEINS</h2>
        <p>Panel de Administración</p>
    </div>

    <nav class="sidebar-nav">
        <div class="nav-section-title">Principal</div>
        <a href="MenuAdmin.jsp" class="nav-item">
            <span class="icon">🏠</span> Dashboard
        </a>

        <div class="nav-section-title">Gestión</div>
        <a href="Productos.jsp" class="nav-item">
            <span class="icon">📦</span> Productos
        </a>
        <a href="Clientes.jsp" class="nav-item">
            <span class="icon">👥</span> Clientes
        </a>
        <a href="Fiado.jsp" class="nav-item">
            <span class="icon">📋</span> Fiado
        </a>
        <a href="Proveedores.jsp" class="nav-item active">
            <span class="icon">🏭</span> Proveedores
        </a>

        <div class="nav-section-title">Configuración</div>
        <a href="MedioPago.jsp" class="nav-item">
            <span class="icon">💳</span> Medios de Pago
        </a>
        <a href="Roles.jsp" class="nav-item">
            <span class="icon">🔑</span> Roles
        </a>
        <a href="TipoDocumento.jsp" class="nav-item">
            <span class="icon">🪪</span> Tipo Documento
        </a>

        <div class="nav-section-title">Usuarios</div>
        <a href="RegistroUsuario.jsp" class="nav-item">
            <span class="icon">👤</span> Usuarios
        </a>
    </nav>

    <div class="sidebar-footer">
        <span style="display:block; font-size:0.78rem; color:rgba(212,175,55,0.5); margin-bottom:10px;">
            👋 <%= usuario %>
        </span>
        <a href="../Login.jsp" class="btn-logout">Cerrar Sesión</a>
    </div>
</aside>
<% } %>

<!-- ══════════════════ CONTENIDO PRINCIPAL ══════════════════ -->
<main class="main-content">

<%
    ProveedorDAO dao = new ProveedorDAO();
    String mensaje  = "";
    String tipoMsg  = "";
    int editId      = 0;
    String editRazon = "";
    String editNit   = "";

    String accion = request.getParameter("accion");

    if ("insertar".equals(accion)) {
        Proveedores p = new Proveedores();
        p.setRazon_social(request.getParameter("razon"));
        p.setNit(request.getParameter("nit"));
        if (dao.insertar(p)) {
            mensaje  = "✅ Proveedor registrado correctamente";
            tipoMsg  = "success";
        } else {
            mensaje  = "❌ Error al registrar el proveedor (¿NIT duplicado?)";
            tipoMsg  = "error";
        }

    } else if ("actualizar".equals(accion)) {
        Proveedores p = new Proveedores();
        p.setId_proveedores(Integer.parseInt(request.getParameter("id")));
        p.setRazon_social(request.getParameter("razon"));
        p.setNit(request.getParameter("nit"));
        if (dao.actualizar(p)) {
            mensaje  = "✅ Proveedor actualizado correctamente";
            tipoMsg  = "success";
        } else {
            mensaje  = "❌ Error al actualizar el proveedor";
            tipoMsg  = "error";
        }

    } else if ("eliminar".equals(accion)) {
        int id = Integer.parseInt(request.getParameter("id"));
        if (dao.eliminar(id)) {
            mensaje  = "✅ Proveedor retirado del listado. Sus compras y pagos anteriores se conservan.";
            tipoMsg  = "success";
        } else {
            mensaje  = "❌ No se encontró el proveedor o ya había sido retirado.";
            tipoMsg  = "error";
        }

    } else if ("actualizar_deuda".equals(accion)) {
        try (Connection con = new Conexion().getConnection();
             PreparedStatement ps = con.prepareStatement("UPDATE proveedores SET saldo_deuda=? WHERE id_proveedores=?")) {
            double saldo = Double.parseDouble(request.getParameter("saldo_deuda"));
            if (saldo < 0) throw new IllegalArgumentException("El saldo no puede ser negativo.");
            ps.setDouble(1, saldo);
            ps.setInt(2, Integer.parseInt(request.getParameter("id")));
            ps.executeUpdate();
            mensaje = "✅ Deuda del proveedor actualizada";
            tipoMsg = "success";
        } catch (Exception e) {
            mensaje = "❌ No se pudo actualizar la deuda: " + e.getMessage();
            tipoMsg = "error";
        }

    } else if ("editar".equals(accion)) {
        // Cargar datos en el formulario
        editId    = Integer.parseInt(request.getParameter("id"));
        editRazon = request.getParameter("razon");
        editNit   = request.getParameter("nit");
    }

    List<Proveedores> lista = dao.listar();
    Map<Integer, Double> saldosProveedor = new HashMap<Integer, Double>();
    double totalPorPagar = 0;
    try (Connection con = new Conexion().getConnection();
         PreparedStatement psSaldo = con.prepareStatement("SELECT id_proveedores, COALESCE(saldo_deuda,0) saldo_deuda FROM proveedores");
         ResultSet rsSaldo = psSaldo.executeQuery()) {
        while (rsSaldo.next()) {
            double saldo = rsSaldo.getDouble("saldo_deuda");
            saldosProveedor.put(rsSaldo.getInt("id_proveedores"), saldo);
            totalPorPagar += saldo;
        }
    } catch (Exception e) { /* La lista sigue disponible aunque no haya movimientos todavía. */ }
    java.text.NumberFormat moneda = java.text.NumberFormat.getIntegerInstance(new java.util.Locale("es", "CO"));
%>

    <div class="page-header">
        <h1>🏭 Proveedores</h1>
        <p>Cartera por pagar: consulta cuánto se le debe a cada proveedor</p>
    </div>

    <% if (!mensaje.isEmpty()) { %>
        <div class="alert alert-<%= tipoMsg %>"><%= mensaje %></div>
    <% } %>

    <section class="table-card" style="margin-bottom:24px">
        <div class="table-card-header"><h3>💳 Cartera con proveedores</h3><span class="count-badge">Total pendiente: $ <%= moneda.format(totalPorPagar) %></span></div>
        <div style="padding:18px 24px;color:rgba(224,212,180,.72);font-size:.9rem">El saldo se actualiza al registrar compras y abonos a proveedores. En la lista inferior puedes ver el valor exacto de cada proveedor.</div>
    </section>

    <div class="layout">

        <!-- ── FORMULARIO ── -->
        <div class="form-card">
            <h2><%= editId > 0 ? "✏️ Editar Proveedor" : "➕ Nuevo Proveedor" %></h2>

            <% if (editId > 0) { %>
                <div class="edit-badge">✏️ Modo edición — Proveedor #<%= editId %></div>
            <% } %>

            <form action="Proveedores.jsp<%= embedAdmin ? "?embed=1" : "" %>" method="post">
                <input type="hidden" name="accion" value="<%= editId > 0 ? "actualizar" : "insertar" %>">
                <% if (editId > 0) { %>
                    <input type="hidden" name="id" value="<%= editId %>">
                <% } %>

                <div class="form-group">
                    <label for="razon">Razón Social</label>
                    <input type="text" id="razon" name="razon"
                           value="<%= editRazon %>"
                           placeholder="Ej: Distribuidora La Esperanza S.A.S"
                           required>
                </div>

                <div class="form-group">
                    <label for="nit">NIT</label>
                    <input type="text" id="nit" name="nit"
                           value="<%= editNit %>"
                           placeholder="Ej: 900123456-7"
                           required>
                </div>

                <div class="btn-row">
                    <button type="submit" class="btn-primary">
                        <%= editId > 0 ? "💾 Guardar Cambios" : "➕ Registrar Proveedor" %>
                    </button>
                    <% if (editId > 0) { %>
                        <a href="Proveedores.jsp<%= embedAdmin ? "?embed=1" : "" %>" class="btn-secondary">✕ Cancelar</a>
                    <% } else { %>
                        <button type="reset" class="btn-secondary">🔄 Limpiar</button>
                    <% } %>
                </div>
            </form>
        </div>

        <!-- ── TABLA ── -->
        <div class="table-card">
            <div class="table-card-header">
                <h3>Lista de Proveedores</h3>
                <span class="count-badge"><%= lista.size() %> registros</span>
            </div>

            <% if (lista.isEmpty()) { %>
                <div class="empty-state">
                    <div class="empty-icon">🏭</div>
                    <p>No hay proveedores registrados aún</p>
                </div>
            <% } else { %>
                <table>
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Razón Social</th>
                            <th>NIT</th>
                            <th>Saldo pendiente</th>
                            <th>Estado</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <% for (Proveedores p : lista) { %>
                        <tr>
                            <td><%= p.getId_proveedores() %></td>
                            <td><%= p.getRazon_social() %></td>
                            <td><span class="nit-badge"><%= p.getNit() %></span></td>
                            <% double saldoProveedor = saldosProveedor.containsKey(p.getId_proveedores()) ? saldosProveedor.get(p.getId_proveedores()) : 0; %>
                            <td style="font-weight:700;color:<%= saldoProveedor > 0 ? "#e74c3c" : "#2ecc71" %>">$ <%= moneda.format(saldoProveedor) %></td>
                            <td><span class="nit-badge" style="color:<%= saldoProveedor > 0 ? "#e74c3c" : "#2ecc71" %>"><%= saldoProveedor > 0 ? "Por pagar" : "Al día" %></span></td>
                            <td>
                                <div class="action-btns">
                                    <form action="Proveedores.jsp<%= embedAdmin ? "?embed=1" : "" %>" method="post" style="display:inline-flex;gap:6px;align-items:center;flex-wrap:wrap;">
                                        <input type="hidden" name="accion" value="actualizar_deuda">
                                        <input type="hidden" name="id" value="<%= p.getId_proveedores() %>">
                                        <input aria-label="Deuda de <%= p.getRazon_social() %>" type="number" name="saldo_deuda" min="0" step="1000" value="<%= Math.round(saldoProveedor) %>" style="width:118px;padding:6px 8px;">
                                        <button type="submit" class="btn-edit">💳 Guardar deuda</button>
                                    </form>
                                    <!-- Botón Editar: envía datos al formulario -->
                                    <form action="Proveedores.jsp<%= embedAdmin ? "?embed=1" : "" %>" method="post" style="display:inline;">
                                        <input type="hidden" name="accion" value="editar">
                                        <input type="hidden" name="id"    value="<%= p.getId_proveedores() %>">
                                        <input type="hidden" name="razon" value="<%= p.getRazon_social() %>">
                                        <input type="hidden" name="nit"   value="<%= p.getNit() %>">
                                        <button type="submit" class="btn-edit">✏️ Editar</button>
                                    </form>

                                    <!-- Botón Eliminar con confirmación -->
                                    <form action="Proveedores.jsp<%= embedAdmin ? "?embed=1" : "" %>" method="post" style="display:inline;"
                                          onsubmit="return confirm('¿Retirar al proveedor \'<%= p.getRazon_social() %>\' del listado?\nSus compras y pagos históricos se conservarán.');">
                                        <input type="hidden" name="accion" value="eliminar">
                                        <input type="hidden" name="id"    value="<%= p.getId_proveedores() %>">
                                        <button type="submit" class="btn-delete">🗑️ Retirar</button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                        <% } %>
                    </tbody>
                </table>
            <% } %>
        </div>

    </div><!-- /layout -->

</main>

<script>
(function () {
    const params = new URLSearchParams(window.location.search);
    if (params.get('embed') !== '1') return;

    document.querySelectorAll('form').forEach(form => {
        if (!form.querySelector('input[name="embed"]')) {
            const input = document.createElement('input');
            input.type = 'hidden';
            input.name = 'embed';
            input.value = '1';
            form.appendChild(input);
        }
    });

    document.querySelectorAll('a[href]').forEach(link => {
        const href = link.getAttribute('href');
        if (!href || href.startsWith('#') || href.startsWith('http') || href.includes('LogoutServlet') || href.includes('Login.jsp')) return;
        if (!href.includes('.jsp')) return;
        const url = new URL(href, window.location.href);
        url.searchParams.set('embed', '1');
        link.setAttribute('href', url.pathname.split('/').pop() + url.search + url.hash);
    });
})();
</script>
    <script src="../Scripts/premium-ui.js"></script>
</body>
</html>
