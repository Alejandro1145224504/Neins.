<%@page contentType="application/json" pageEncoding="UTF-8"%>
<%@page import="java.net.HttpURLConnection,java.net.URL,java.io.OutputStream,java.nio.charset.StandardCharsets,java.security.SecureRandom"%>
<%
response.setCharacterEncoding("UTF-8");
String correo = request.getParameter("correo");
if (correo == null || !correo.matches("^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$")) {
    out.print("{\"ok\":false,\"message\":\"Escribe un correo válido.\"}");
    return;
}
String apiKey = System.getenv("BREVO_API_KEY");
String remitente = System.getenv("MAIL_FROM");
if (apiKey == null || apiKey.trim().isEmpty() || remitente == null || remitente.trim().isEmpty()) {
    out.print("{\"ok\":false,\"message\":\"El correo de verificación aún no está configurado.\"}");
    return;
}
String codigo = String.format("%06d", new SecureRandom().nextInt(1000000));
session.setAttribute("registroCorreo", correo.trim().toLowerCase());
session.setAttribute("registroCodigo", codigo);
session.setAttribute("registroCodigoExpira", System.currentTimeMillis() + 600000L);
try {
    URL url = new URL("https://api.brevo.com/v3/smtp/email");
    HttpURLConnection conexion = (HttpURLConnection) url.openConnection();
    conexion.setRequestMethod("POST");
    conexion.setConnectTimeout(10000);
    conexion.setReadTimeout(10000);
    conexion.setDoOutput(true);
    conexion.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
    conexion.setRequestProperty("Accept", "application/json");
    conexion.setRequestProperty("api-key", apiKey.trim());
    String asunto = "Código de verificación - Una Pa' La Sed";
    String html = "<div style='font-family:Arial,sans-serif;color:#211805'><h2>Una Pa' La Sed</h2><p>Tu código de verificación es:</p><p style='font-size:28px;font-weight:bold;letter-spacing:5px'>" + codigo + "</p><p>Vence en 10 minutos. No lo compartas.</p></div>";
    String json = "{\"sender\":{\"email\":\"" + remitente.trim().replace("\\", "\\\\").replace("\"", "\\\"") + "\",\"name\":\"Una Pa' La Sed\"},\"to\":[{\"email\":\"" + correo.trim().replace("\\", "\\\\").replace("\"", "\\\"") + "\"}],\"subject\":\"" + asunto + "\",\"htmlContent\":\"" + html.replace("\\", "\\\\").replace("\"", "\\\"") + "\"}";
    try (OutputStream salida = conexion.getOutputStream()) { salida.write(json.getBytes(StandardCharsets.UTF_8)); }
    int estado = conexion.getResponseCode();
    if (estado >= 200 && estado < 300) out.print("{\"ok\":true,\"message\":\"Enviamos un código de 6 dígitos a tu correo. Vence en 10 minutos.\"}");
    else out.print("{\"ok\":false,\"message\":\"El servicio de correo rechazó el envío.\"}");
} catch (Exception e) {
    application.log("Error enviando correo de verificación", e);
    out.print("{\"ok\":false,\"message\":\"No fue posible enviar el correo. Intenta nuevamente más tarde.\"}");
}
%>
