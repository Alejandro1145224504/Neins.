# Mejoras aplicadas

- Conexion a MySQL configurable con `NEINS_DB_URL`, `NEINS_DB_USER` y `NEINS_DB_PASSWORD`, conservando los valores locales por defecto.
- Login web con validacion de campos obligatorios y renovacion de sesion al autenticar.
- API de login con respuesta `400` cuando faltan correo o clave.
- Recuperacion de clave sin exponer la clave/hash guardado; ahora redirige a cambio de clave.
- Cambio de clave con politica minima de 8 caracteres, letras y numeros, e invalidacion de sesion al finalizar.
- Registro alineado con la misma politica de clave.
- Validacion de `identificacion` duplicada alineada con el SQL, donde esa columna es unica.
- `Menu.jsp` y `diagnostico.jsp` usan el helper comun de conexion.
- CORS responde correctamente solicitudes `OPTIONS`.
- Se agrego `database/Neins_SQL_FINAL.sql` a partir del SQL final adjunto.

## Verificacion

- Compilacion Java con `javac --release 17` completada correctamente.
- `dist/Neins.war` regenerado desde `build/web`.

## Segunda ronda de mejoras

- Refresh visual global: paleta mas equilibrada, tarjetas de 8px, tablas mas legibles, botones con mejores estados, formularios mas claros y responsive mejorado.
- Portada inicial redisenada con imagen protagonista, texto sin tarjeta pesada y login en panel compacto.
- Carrito del cliente sin `innerHTML` dinamico para reducir riesgo de HTML roto o inyeccion.
- DAOs principales con columnas explicitas en vez de `SELECT *`.
- DAOs y API de fiados con cierre automatico de recursos.
- API de fiados responde `400` cuando recibe datos numericos invalidos.
- Pantalla de cambio de clave escapa el correo antes de imprimirlo.

## Tercera ronda de mejoras

- Escapado HTML agregado en pantallas administrativas clave: clientes, historial, productos, registro de usuarios, fiados y menu cliente antiguo.
- Mensajes de confirmacion inline simplificados para no mezclar datos de usuario dentro de JavaScript.
- Consultas restantes de productos pasadas a columnas explicitas y `PreparedStatement`.
- Se redujeron mas puntos donde nombres, correos o documentos podian romper la interfaz.

## Cuarta ronda de mejoras

- Se restauro la identidad visual negro + dorado en toda la capa global.
- La pagina principal vuelve a tener el contenido y formularios centrados.
- Se quitaron acentos frios/azules de la propuesta anterior.
- Se ajustaron superficies, bordes, sombras y estados hover para una apariencia mas premium y consistente.
