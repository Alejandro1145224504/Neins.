-- Catálogo listo para demostración: precios aproximados en pesos colombianos.
USE Neins;

UPDATE Productos SET precio=45000, stock=24, estado=1 WHERE nombre='Cerveza Poker x24';
UPDATE Productos SET precio=32000, stock=18, estado=1 WHERE nombre='Aguardiente 750ml';
UPDATE Productos SET precio=185000, stock=8, estado=1 WHERE nombre='Whisky Black Label';
UPDATE Productos SET precio=42000, stock=15, estado=1 WHERE nombre='Ron Medellin 750ml';
UPDATE Productos SET precio=48000, stock=12, estado=1 WHERE nombre='Vino Tinto 750ml';

INSERT INTO Productos (nombre, precio, stock, stock_minimo, id_categoria)
SELECT 'Cerveza Aguila Lata 330ml', 4500, 48, 12, 2
WHERE NOT EXISTS (SELECT 1 FROM Productos WHERE nombre='Cerveza Aguila Lata 330ml');
INSERT INTO Productos (nombre, precio, stock, stock_minimo, id_categoria)
SELECT 'Cerveza Aguila Six Pack', 21000, 18, 6, 2
WHERE NOT EXISTS (SELECT 1 FROM Productos WHERE nombre='Cerveza Aguila Six Pack');
INSERT INTO Productos (nombre, precio, stock, stock_minimo, id_categoria)
SELECT 'Corona Extra Six Pack', 55000, 10, 4, 2
WHERE NOT EXISTS (SELECT 1 FROM Productos WHERE nombre='Corona Extra Six Pack');
INSERT INTO Productos (nombre, precio, stock, stock_minimo, id_categoria)
SELECT 'Buchanan''s Master 750ml', 260000, 6, 2, 1
WHERE NOT EXISTS (SELECT 1 FROM Productos WHERE nombre='Buchanan''s Master 750ml');
INSERT INTO Productos (nombre, precio, stock, stock_minimo, id_categoria)
SELECT 'Aguardiente Nectar Club 750ml', 37000, 10, 4, 4
WHERE NOT EXISTS (SELECT 1 FROM Productos WHERE nombre='Aguardiente Nectar Club 750ml');
